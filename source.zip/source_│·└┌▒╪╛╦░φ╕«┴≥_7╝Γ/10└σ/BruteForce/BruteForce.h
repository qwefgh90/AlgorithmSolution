#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H

int BruteForce(char* Text, int TextSize, int Start, 
               char* Pattern, int PatternSize );

#endif